/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

import java.util.Scanner;
/**
 *
 * @author Estudiantes
 */
public class Calculadora {

    /**
     * @param args the command line arguments
     */  public static void main(String[] args) {
        // TODO code application logic here
        Logica calculadora=new Logica();
        Scanner sc = new Scanner (System.in);
        System.out.println("Ingrese operando 1: ");
        calculadora.setOperando1 (sc.nextInt());
        System.out.println("Ingrese operando 2: ");
        calculadora.setOperando2 (sc.nextInt());
        calculadora.sumar();
        System.out.println(calculadora.getResultado());
        calculadora.restar();
        System.out.println(calculadora.getResultado());
        calculadora.multiplicar();
        System.out.println(calculadora.getResultado());
        calculadora.dividir();
        System.out.println(calculadora.getResultado());
    }
    
}
