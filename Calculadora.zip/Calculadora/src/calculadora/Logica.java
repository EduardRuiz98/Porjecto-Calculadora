/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadora;

/**
 *
 * @author Estudiantes
 */
public class Logica {
    int Operando1;
    int Operando2;
    int Resultado;
    public void setOperando1(int valor){
        Operando1=valor;
    }
    public void setOperando2(int valor){
        Operando2=valor;
    }
    public int getResultado (){
        return Resultado;
    }
    public void sumar (){
        Resultado=Operando1+Operando2;
    }
    public void restar (){
        Resultado=Operando1-Operando2;
    }
    public void multiplicar (){
        Resultado=Operando1*Operando2;
    }
    public void dividir (){
        Resultado=Operando1/Operando2;
    }
    
}
